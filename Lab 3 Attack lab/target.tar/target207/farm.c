/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_336()
{
    return 1485632283U;
}

unsigned getval_330()
{
    return 2009305176U;
}

void setval_253(unsigned *p)
{
    *p = 2425393368U;
}

unsigned getval_203()
{
    return 2445773128U;
}

void setval_131(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_390(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_401(unsigned x)
{
    return x + 2425393224U;
}

void setval_334(unsigned *p)
{
    *p = 3347671242U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_127(unsigned *p)
{
    *p = 3229929096U;
}

unsigned getval_140()
{
    return 2430601544U;
}

unsigned getval_174()
{
    return 3374371209U;
}

unsigned getval_206()
{
    return 3380920969U;
}

unsigned getval_135()
{
    return 3674784425U;
}

unsigned getval_395()
{
    return 3680551561U;
}

unsigned addval_396(unsigned x)
{
    return x + 2429421943U;
}

unsigned addval_257(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_496()
{
    return 3525890441U;
}

unsigned addval_300(unsigned x)
{
    return x + 3281047961U;
}

unsigned getval_445()
{
    return 3247493513U;
}

void setval_150(unsigned *p)
{
    *p = 2497743176U;
}

void setval_288(unsigned *p)
{
    *p = 2425409931U;
}

unsigned addval_187(unsigned x)
{
    return x + 3766569147U;
}

unsigned getval_198()
{
    return 3372797593U;
}

unsigned addval_164(unsigned x)
{
    return x + 3383021193U;
}

unsigned getval_202()
{
    return 3767093465U;
}

void setval_212(unsigned *p)
{
    *p = 3532968329U;
}

unsigned getval_432()
{
    return 3223375501U;
}

unsigned getval_338()
{
    return 3221802633U;
}

unsigned addval_485(unsigned x)
{
    return x + 3677409673U;
}

unsigned getval_301()
{
    return 3281047177U;
}

unsigned getval_171()
{
    return 3284306250U;
}

unsigned getval_358()
{
    return 3674788233U;
}

unsigned getval_490()
{
    return 3685008009U;
}

unsigned addval_497(unsigned x)
{
    return x + 3683962505U;
}

unsigned addval_423(unsigned x)
{
    return x + 3525886601U;
}

unsigned getval_266()
{
    return 247710361U;
}

void setval_453(unsigned *p)
{
    *p = 3380134537U;
}

void setval_151(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_267(unsigned x)
{
    return x + 2430638408U;
}

unsigned getval_452()
{
    return 3286272360U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
